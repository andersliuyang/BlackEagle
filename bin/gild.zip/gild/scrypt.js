// Minimal scrypt implementation for browser usage (derived from scrypt-js, MIT).
// Exposes: scrypt(passwordBytes, saltBytes, N, r, p, dkLen) -> Promise<Uint8Array>

const rotl = (value, shift) => (value << shift) | (value >>> (32 - shift));

const salsa20_8 = (B) => {
  const x = new Uint32Array(16);
  for (let i = 0; i < 16; i += 1) {
    x[i] = B[i];
  }
  for (let i = 0; i < 8; i += 2) {
    x[4] ^= rotl((x[0] + x[12]) | 0, 7);
    x[8] ^= rotl((x[4] + x[0]) | 0, 9);
    x[12] ^= rotl((x[8] + x[4]) | 0, 13);
    x[0] ^= rotl((x[12] + x[8]) | 0, 18);
    x[9] ^= rotl((x[5] + x[1]) | 0, 7);
    x[13] ^= rotl((x[9] + x[5]) | 0, 9);
    x[1] ^= rotl((x[13] + x[9]) | 0, 13);
    x[5] ^= rotl((x[1] + x[13]) | 0, 18);
    x[14] ^= rotl((x[10] + x[6]) | 0, 7);
    x[2] ^= rotl((x[14] + x[10]) | 0, 9);
    x[6] ^= rotl((x[2] + x[14]) | 0, 13);
    x[10] ^= rotl((x[6] + x[2]) | 0, 18);
    x[3] ^= rotl((x[15] + x[11]) | 0, 7);
    x[7] ^= rotl((x[3] + x[15]) | 0, 9);
    x[11] ^= rotl((x[7] + x[3]) | 0, 13);
    x[15] ^= rotl((x[11] + x[7]) | 0, 18);
    x[1] ^= rotl((x[0] + x[3]) | 0, 7);
    x[2] ^= rotl((x[1] + x[0]) | 0, 9);
    x[3] ^= rotl((x[2] + x[1]) | 0, 13);
    x[0] ^= rotl((x[3] + x[2]) | 0, 18);
    x[6] ^= rotl((x[5] + x[4]) | 0, 7);
    x[7] ^= rotl((x[6] + x[5]) | 0, 9);
    x[4] ^= rotl((x[7] + x[6]) | 0, 13);
    x[5] ^= rotl((x[4] + x[7]) | 0, 18);
    x[11] ^= rotl((x[10] + x[9]) | 0, 7);
    x[8] ^= rotl((x[11] + x[10]) | 0, 9);
    x[9] ^= rotl((x[8] + x[11]) | 0, 13);
    x[10] ^= rotl((x[9] + x[8]) | 0, 18);
    x[12] ^= rotl((x[15] + x[14]) | 0, 7);
    x[13] ^= rotl((x[12] + x[15]) | 0, 9);
    x[14] ^= rotl((x[13] + x[12]) | 0, 13);
    x[15] ^= rotl((x[14] + x[13]) | 0, 18);
  }
  for (let i = 0; i < 16; i += 1) {
    B[i] = (B[i] + x[i]) | 0;
  }
};

const blockMix = (B, Y, r) => {
  const X = new Uint32Array(16);
  for (let i = 0; i < 16; i += 1) {
    X[i] = B[B.length - 16 + i];
  }
  for (let i = 0; i < 2 * r; i += 1) {
    for (let j = 0; j < 16; j += 1) {
      X[j] ^= B[i * 16 + j];
    }
    salsa20_8(X);
    const dest = (i % 2 === 0 ? i / 2 : r + (i - 1) / 2) * 16;
    for (let j = 0; j < 16; j += 1) {
      Y[dest + j] = X[j];
    }
  }
};

const integerify = (B, r) => {
  return B[(2 * r - 1) * 16] >>> 0;
};

const smix = (B, r, N, V, XY) => {
  let Xi = 0;
  let Yi = 32 * r;
  for (let i = 0; i < 32 * r; i += 1) {
    XY[Xi + i] = B[i];
  }
  for (let i = 0; i < N; i += 1) {
    V.set(XY.subarray(Xi, Xi + 32 * r), i * 32 * r);
    blockMix(XY.subarray(Xi, Xi + 32 * r), XY.subarray(Yi, Yi + 32 * r), r);
    const tmp = Xi;
    Xi = Yi;
    Yi = tmp;
  }
  for (let i = 0; i < N; i += 1) {
    const j = integerify(XY.subarray(Xi, Xi + 32 * r), r) & (N - 1);
    for (let k = 0; k < 32 * r; k += 1) {
      XY[Xi + k] ^= V[j * 32 * r + k];
    }
    blockMix(XY.subarray(Xi, Xi + 32 * r), XY.subarray(Yi, Yi + 32 * r), r);
    const tmp = Xi;
    Xi = Yi;
    Yi = tmp;
  }
  for (let i = 0; i < 32 * r; i += 1) {
    B[i] = XY[Xi + i];
  }
};

const pbkdf2 = async (password, salt, iterations, dkLen) => {
  const key = await crypto.subtle.importKey("raw", password, "PBKDF2", false, ["deriveBits"]);
  const bits = await crypto.subtle.deriveBits({ name: "PBKDF2", hash: "SHA-256", salt, iterations }, key, dkLen * 8);
  return new Uint8Array(bits);
};

export const scrypt = async (password, salt, N, r, p, dkLen) => {
  if ((N & (N - 1)) !== 0 || N <= 1) {
    throw new Error("N must be > 1 and a power of 2");
  }
  const B = await pbkdf2(password, salt, 1, p * 128 * r);
  const B32 = new Uint32Array(B.buffer);
  const V = new Uint32Array(32 * r * N);
  const XY = new Uint32Array(64 * r);
  for (let i = 0; i < p; i += 1) {
    smix(B32.subarray(i * 32 * r, (i + 1) * 32 * r), r, N, V, XY);
  }
  return pbkdf2(password, B, 1, dkLen);
};
