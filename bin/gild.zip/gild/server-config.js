const SERVER_CONFIG = {
  envs: {
    local: "http://127.0.0.1:3000",
    prod: "https://api.cozyai.chat",
  },
  defaultEnv: "prod",
};

function getServerBaseForEnv(env) {
  if (!env) {
    return SERVER_CONFIG.envs[SERVER_CONFIG.defaultEnv];
  }
  if (Object.prototype.hasOwnProperty.call(SERVER_CONFIG.envs, env)) {
    return SERVER_CONFIG.envs[env];
  }
  return SERVER_CONFIG.envs[SERVER_CONFIG.defaultEnv];
}

function normalizeServerEnv(env, serverBase) {
  if (env && Object.prototype.hasOwnProperty.call(SERVER_CONFIG.envs, env)) {
    return env;
  }
  if (typeof serverBase === "string" && serverBase.includes("127.0.0.1")) {
    return "local";
  }
  return "prod";
}

if (typeof window !== "undefined") {
  window.SERVER_CONFIG = SERVER_CONFIG;
  window.getServerBaseForEnv = getServerBaseForEnv;
  window.normalizeServerEnv = normalizeServerEnv;
}
