function init() {
  console.log("Weixin script loaded");
  chrome.runtime.onMessage.addListener((message, sender, sendResponse) => {
    if (message.type === "PUBLISH_WEIXINMP") {
      const title = message.payload.title;
      const auth = message.payload.auth;
      const content = message.payload.content;
      const titleText = document.querySelector('textarea[placeholder="请在这里输入标题"]');
      if (titleText) {
        titleText.value = title;
        const event = new Event("input", { bubbles: true });
        titleText.dispatchEvent(event);
      }

      const authText = document.querySelector('input[placeholder="请输入作者"]');
      if (authText) {
        authText.value = auth;
        const event = new Event("input", { bubbles: true });
        authText.dispatchEvent(event);
      }

      const editor = document.querySelector('div.ProseMirror[contenteditable="true"]');
      if (editor) {
        editor.focus();
        editor.innerHTML = content;
        editor.dispatchEvent(new Event("input", { bubbles: true }));
        editor.dispatchEvent(new Event("change", { bubbles: true }));
      }
      sendResponse({ success: true, message: "Content filled" });
    }
  });
}

init();
