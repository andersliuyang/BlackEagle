function init() {
  console.log("Weibo script loaded");
  chrome.runtime.onMessage.addListener((message, sender, sendResponse) => {
    if (message.type === "PUBLISH_WEIBO") {
      const content = message.payload.content;
      const textarea = document.querySelector('textarea[placeholder="有什么新鲜事想分享给大家？"]');
      if (textarea) {
        textarea.value = content; // 填入内容

        const event = new Event("input", { bubbles: true });
        textarea.dispatchEvent(event);

        sendResponse({ success: true, message: "Content filled" });
      } else {
        sendResponse({ success: false, message: "Input not found" });
      }
    }
  });
}

init();
