// content.js

// 创建工具栏容器
const toolbar = document.createElement("div");
toolbar.id = "my-extension-toolbar";
toolbar.style.position = "fixed";
toolbar.style.top = "50%";
toolbar.style.right = "0";
toolbar.style.transform = "translateY(-50%)";
toolbar.style.display = "flex";
toolbar.style.flexDirection = "column";
toolbar.style.gap = "10px";
toolbar.style.zIndex = "999999"; // 保证在最上层
toolbar.style.background = "rgba(255, 255, 255, 0.9)";
toolbar.style.padding = "10px";
toolbar.style.borderRadius = "8px 0 0 8px";
toolbar.style.boxShadow = "0 0 10px rgba(0,0,0,0.3)";

// 工具图标列表，可以自定义
const tools = [
  { name: "tool1", icon: "🔧" },
  { name: "tool2", icon: "📄" },
  { name: "tool3", icon: "⚙️" },
];

// 创建每个图标按钮
tools.forEach((tool) => {
  const btn = document.createElement("button");
  btn.innerText = tool.icon;
  btn.title = tool.name;
  btn.style.width = "40px";
  btn.style.height = "40px";
  btn.style.border = "none";
  btn.style.borderRadius = "6px";
  btn.style.cursor = "pointer";
  btn.style.fontSize = "20px";
  btn.style.background = "#fff";
  btn.style.boxShadow = "0 0 5px rgba(0,0,0,0.2)";

  // 点击图标时打开插件侧边栏
  btn.addEventListener("click", () => {});

  toolbar.appendChild(btn);
});

// 添加到页面
// document.body.appendChild(toolbar);
