function init() {
  console.log("Xiaohongshu script loaded");
  chrome.runtime.onMessage.addListener((message, sender, sendResponse) => {
    if (message.type === "PUBLISH_XIAOHONGSHU_LONGTEXT") {
      const title = message.payload.title;
      const content = message.payload.content;
      var titleText = document.querySelector('textarea.d-text[placeholder="输入标题"]');
      if (!titleText) {
        titleText = document.querySelector('input.d-text[placeholder="填写标题会有更多赞哦～"]');
      }
      console.log("in");
      if (titleText) {
        console.log("::::::" + title);
        titleText.value = title; // 填入内容
        const event = new Event("input", { bubbles: true });
        titleText.dispatchEvent(event);
      }

      const editor = document.querySelector('div.tiptap.ProseMirror[contenteditable="true"]');
      if (editor) {
        console.log("::::::" + content);
        editor.focus();
        editor.innerHTML = content;
        editor.dispatchEvent(new Event("input", { bubbles: true }));
        editor.dispatchEvent(new Event("change", { bubbles: true }));
      }
      sendResponse({ success: true, message: "Content filled" });
    }
  });
}
init();
