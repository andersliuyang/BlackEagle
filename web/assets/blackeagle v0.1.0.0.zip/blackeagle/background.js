importScripts("taskModule.js");

let pageState = { inData: {}, pageName: "home", llmname: "" };
let sidebarOpen = false;
let webcontent = {};

TaskModule.init();

chrome.action.onClicked.addListener(async (tab) => {
  chrome.sidePanel.setOptions(
    {
      path: "sidebar.html",
      tabId: tab.id,
    },
    () => {
      chrome.sidePanel.open({ tabId: tab.id });
      sidebarOpen = true;
    }
  );
});

chrome.tabs.onUpdated.addListener((tabId, changeInfo, tab) => {
  if (changeInfo.status === "loading") {
    webcontent.loading = true;
    chrome.runtime.sendMessage({ type: "CHANGE_WEB", webcontent: webcontent }, () => {
      void chrome.runtime.lastError;
    });
  }
});

chrome.tabs.onActivated.addListener(async (activeInfo) => {
  try {
    chrome.tabs.sendMessage(activeInfo.tabId, { type: "READ_WEB" }, (responseFromContent) => {
      const err = chrome.runtime.lastError;
      if (err) {
        // Swallow "receiving end does not exist" when no content script is injected on the tab.
        return;
      }
      if (!responseFromContent) {
        chrome.tabs.get(activeInfo.tabId, (tab) => {
          if (tab.url.startsWith("http")) {
            webcontent.loading = true;
            chrome.runtime.sendMessage({ type: "CHANGE_WEB", webcontent: webcontent }, () => {
              void chrome.runtime.lastError;
            });
          } else {
            chrome.runtime.sendMessage({ type: "CHANGE_WEB", webcontent: {} }, () => {
              void chrome.runtime.lastError;
            });
          }
        });
      } else if (responseFromContent.webcontent) {
        webcontent = responseFromContent.webcontent;
        webcontent.loading = false;
        chrome.runtime.sendMessage({ type: "CHANGE_WEB", webcontent: webcontent }, () => {
          void chrome.runtime.lastError;
        });
      }
    });
  } catch (error) {
    console.error("Error getting active tab:", error);
  }
});

async function focusOrCreateTargetTab(url) {
  // 查询当前所有标签页
  const tabs = await chrome.tabs.query({});

  // 遍历查找是否有包含目标域名的标签页
  for (const tab of tabs) {
    if (tab.url && (tab.url.includes(url) || (url.includes("xiaozhi") && tab.url.includes("xiaozhi")))) {
      // 激活该标签页并切换到所在窗口
      await chrome.tabs.update(tab.id, { active: true, url });
      // await chrome.windows.update(tab.windowId, { focused: true });
      // await chrome.tabs.reload(tab.id);
      return;
    }
  }
  // 如果没有则新建一个
  await chrome.tabs.create({ url });
}

chrome.runtime.onMessage.addListener((msg, sender, sendResponse) => {
  if (TaskModule.handleMessage(msg, sendResponse)) {
    return true; // keep channel open for async responses
  }
  // Schedule reminder via alarms + notifications
  if (msg.type === "SCHEDULE_REMINDER") {
    try {
      const payload = msg.payload || {};
      const id = String(payload.id || `reminder_${Date.now()}`);
      const title = String(payload.title || "").trim();
      const message = String(payload.message || "").trim();
      const targetTs = Number(payload.targetTs);
      const periodInMinutes = Number(payload.periodInMinutes);

      if (!title || !message || !Number.isFinite(targetTs)) {
        sendResponse({ success: false, error: "INVALID_PAYLOAD" });
        return true;
      }

      const when = Math.max(Date.now(), targetTs);
      if (Number.isFinite(periodInMinutes) && periodInMinutes > 0) {
        chrome.alarms.create(id, { when, periodInMinutes });
      } else {
        chrome.alarms.create(id, { when });
      }

      // Persist reminder info so service worker can retrieve on alarm
      chrome.storage.local.get(["scheduledReminders"], (res) => {
        const map = res?.scheduledReminders || {};
        map[id] = { title, message, when, periodInMinutes: Number.isFinite(periodInMinutes) ? periodInMinutes : undefined };
        chrome.storage.local.set({ scheduledReminders: map }, () => {
          void chrome.runtime.lastError;
          sendResponse({ success: true, id, when });
        });
      });
    } catch (e) {
      sendResponse({ success: false, error: (e && e.message) || "SCHEDULE_FAILED" });
    }
    return true; // async
  }
  if (msg.type === "CANCEL_REMINDER") {
    try {
      const id = String(msg?.payload?.id || "").trim();
      if (!id) {
        sendResponse({ success: false, error: "INVALID_ID" });
        return true;
      }

      chrome.alarms.clear(id, () => {
        void chrome.runtime.lastError;
      });

      chrome.storage.local.get(["scheduledReminders"], (res) => {
        const map = res?.scheduledReminders || {};
        if (map[id]) {
          delete map[id];
          chrome.storage.local.set({ scheduledReminders: map }, () => {
            void chrome.runtime.lastError;
            sendResponse({ success: true, id });
          });
        } else {
          sendResponse({ success: true, id, note: "not_found" });
        }
      });
    } catch (e) {
      sendResponse({ success: false, error: (e && e.message) || "CANCEL_FAILED" });
    }
    return true;
  }
  if (msg.type === "CHECK_ACTIVE_TAB") {
    //监测当前活动标签页
    chrome.tabs.query({ active: true, currentWindow: true }, (tabs) => {
      const activeTabId = tabs[0]?.id;
      const isActive = sender.tab?.id === activeTabId;
      sendResponse({ isActive });
    });
  }
  if (msg.type === "CANCEL_ALL_REMINDERS") {
    try {
      chrome.alarms.clearAll(() => {
        void chrome.runtime.lastError;
      });
      chrome.storage.local.set({ scheduledReminders: {} }, () => {
        void chrome.runtime.lastError;
        sendResponse({ success: true });
      });
    } catch (e) {
      sendResponse({ success: false, error: (e && e.message) || "CANCEL_ALL_FAILED" });
    }
    return true;
  }
  if (msg.type === "OPEN_AGENTTALK_PANEL") {
    chrome.tabs.query({ active: true, currentWindow: true }, (tabs) => {
      const tabId = tabs?.[0]?.id;
      if (!tabId) {
        sendResponse({ success: false });
        return;
      }
      chrome.sidePanel
        .open({ tabId })
        .then(() => sendResponse({ success: true }))
        .catch(() => sendResponse({ success: false }));
    });
    return true;
  }
  if (msg.type === "CHANGE_WEB") {
    //切换web
    webcontent = msg.webcontent;
    chrome.runtime.sendMessage({ type: "CHANGE_WEB", webcontent: webcontent }, () => {
      void chrome.runtime.lastError;
    });
    sendResponse({ success: true });
  }
  if (msg.type === "SELECTED_TEXT") {
    //选中文本
    chrome.runtime.sendMessage({ type: "SELECTED_TEXT", text: msg.text }, () => {
      void chrome.runtime.lastError;
    });
    sendResponse({ success: true });
  }
  if (msg.type === "OPEN_URL") {
    //打开新标签页
    focusOrCreateTargetTab(msg.payload.url);
    sendResponse({ success: true });
  }
  if (msg.type === "XIAOZHI_TOKEN") {
    //得到登录授权
    chrome.runtime.sendMessage({ type: "TOKEN_READY", token: msg.token }, () => {
      void chrome.runtime.lastError;
    });
    sendResponse({ success: true });
  } else if (msg.type === "SAVE_PAGE_STATE") {
    // 保存页面状态
    pageState = { ...pageState, ...msg.payload };
    sendResponse({ success: true });
  } else if (msg.type === "GET_PAGE_STATE") {
    // 获取当前页面装填
    sendResponse({ payload: pageState });
  } else {
    //转发其它所有插件请求
    chrome.tabs.query({ active: true, currentWindow: true }, (tabs) => {
      tabs.forEach((tab) => {
        if (tab.id !== undefined) {
          chrome.tabs.sendMessage(tab.id, { type: msg.type, payload: msg.payload }, (responseFromContent) => {
            if (chrome.runtime.lastError) {
              sendResponse({ success: false, error: chrome.runtime.lastError.message });
              return;
            }
            console.log(responseFromContent);
            sendResponse(responseFromContent ?? { success: false, error: "NO_RESPONSE" });
          });
        }
      });
    });
  }
  return true;
});

// Alarm listener: show notification and cleanup
chrome.alarms.onAlarm.addListener((alarm) => {
  try {
    const id = alarm?.name || "";
    chrome.storage.local.get(["scheduledReminders"], (res) => {
      const map = res?.scheduledReminders || {};
      const info = map[id];
      if (!info) return;

      const { title, message } = info;
      try {
        chrome.notifications.create(id, {
          type: "basic",
          iconUrl: "icons/icon128.png",
          title: title || "提醒",
          message: message || "",
        });
      } catch (e) {
        // swallow
      }

      // Update next fire time for recurring; otherwise cleanup
      try {
        const period = Number(info?.periodInMinutes);
        if (Number.isFinite(period) && period > 0) {
          const nextWhen = Date.now() + period * 60_000;
          map[id] = { ...info, when: nextWhen };
        } else {
          delete map[id];
        }
        chrome.storage.local.set({ scheduledReminders: map }, () => {
          void chrome.runtime.lastError;
        });
      } catch {}
    });
  } catch (e) {
    // ignore
  }
});

// When a reminder notification is clicked, focus browser and open side panel
chrome.notifications.onClicked.addListener((notificationId) => {
  try {
    chrome.notifications.clear(notificationId, () => {
      void chrome.runtime.lastError;
    });

    // Focus the last focused window, then open side panel on its active tab
    chrome.windows.getLastFocused({ populate: false }, (win) => {
      if (win?.id !== undefined) {
        chrome.windows.update(win.id, { focused: true }, () => {
          void chrome.runtime.lastError;
          chrome.tabs.query({ active: true, windowId: win.id }, (tabs) => {
            const tabId = tabs?.[0]?.id;
            if (!tabId) return;
            chrome.sidePanel
              .open({ tabId })
              .then(() => {
                chrome.sidePanel.setOptions({ path: "sidebar.html", tabId }, () => {
                  void chrome.runtime.lastError;
                });
              })
              .catch(() => {
                // ignore
              });
          });
        });
      }
    });
  } catch (e) {
    // ignore
  }
});
