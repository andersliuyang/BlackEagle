document.getElementById("fillBtn").addEventListener("click", async () => {
  const content = document.getElementById("content").value;

  const [tab] = await chrome.tabs.query({ active: true, currentWindow: true });

  chrome.scripting.executeScript({
    target: { tabId: tab.id },
    func: (content) => {
      // 找到页面中的第一个输入框或可编辑区域
      let contentInput = document.querySelector("textarea, [contenteditable='true']");

      if (contentInput) {
        if (contentInput.tagName.toLowerCase() === "textarea" || contentInput.tagName.toLowerCase() === "input") {
          contentInput.value = content;
          contentInput.dispatchEvent(new Event("input", { bubbles: true }));
        } else if (contentInput.isContentEditable) {
          contentInput.innerHTML = content;
        }
      }
    },
    args: [content],
  });
});
